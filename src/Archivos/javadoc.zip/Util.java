/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tareas.tres.clases;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Jazna
 */
public class Util {

    /**
     * Carga los datos desde el archivo de texto
     * @param archivo, nombre del archivo que contiene los datos
     * @return, colecciòn de jugadores creados usando los datos del archivo
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public static ListaJugadores cargarJugadores(String archivo) throws FileNotFoundException, IOException {
        ListaJugadores lista = new ListaJugadores();
        String cadena;
        FileReader f = new FileReader(archivo);
        BufferedReader b = new BufferedReader(f);
        while ((cadena = b.readLine()) != null) {
            System.out.println(cadena);
            String datos[] = cadena.split(";");
            String nombre = datos[0];
            Jugador jugador = new Jugador(nombre);
            for (int i = 1; i < datos.length; i++) {
                jugador.agregarTiempo(Integer.parseInt(datos[i]));
            }
            lista.agregarJugador(jugador);
        }
        b.close();
        return lista;
    }

    /**
     * Guardar tiempo de un jugador
     * @param jugador, objeto cuyo tiempo será actualizado
     * @return, true en caso de éxito y false en caso contrario
     * @throws IOException 
     */
    public static boolean guardarTiempo(Jugador jugador) throws IOException {
        /* Genera cadena con los datos del jugador y sus juegos actuales */
        String str_datos = jugador.getNombre() + ";";
        boolean nuevo = true;
        for (Integer tiempo : jugador.getTiempos()) {
            str_datos += tiempo + ";";
        }        
        str_datos += "\n";      
        
        /* Guarda los resultados en el archivo de texto */
        String ruta = "Memorice.txt";
        BufferedReader file = new BufferedReader(new FileReader(ruta));
        String line, input = "";

        while((line = file.readLine()) != null){            
            if(line.contains(jugador.getNombre())){
                input += str_datos;
                nuevo = false;
            }
            else
                input += line+"\n";
        }
        input += (nuevo?str_datos:"");
        System.out.println("input : " + input);
        try (FileOutputStream fileOut = new FileOutputStream(ruta)) {
            fileOut.write(input.getBytes());
            fileOut.close();
        }        
        
        return true;
    }
}
